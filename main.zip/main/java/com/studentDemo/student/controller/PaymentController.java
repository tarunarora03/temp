package com.studentDemo.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.studentDemo.student.beans.Payment;
import com.studentDemo.student.service.PaymentService;

@Controller
public class PaymentController {

	@Autowired
	PaymentService paymentService;
	
	@RequestMapping(path = "/payment", method = RequestMethod.GET)
	public String getStudentList(Model model) {
		model.addAttribute("payment",paymentService.getStudents());
		return "studentPayment";
	}
	
	@RequestMapping(path = "/payment", method = RequestMethod.POST)
	public String savePayment(Payment payment) {
		System.out.println(payment.getAmount());
		System.out.println(payment.getStudentId());
		System.out.println(payment.getComments());
		
		paymentService.makePayment(payment);
		
		return "redirect:/payment";
	}
	
	
}
