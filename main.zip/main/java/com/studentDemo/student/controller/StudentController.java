package com.studentDemo.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.studentDemo.student.beans.Student;
import com.studentDemo.student.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	StudentService service;
	
	@RequestMapping(path = "/student", method = RequestMethod.GET)
	public String getStudentsList(Model model) {
		model.addAttribute("student", new Student());
		model.addAttribute("students", service.getStudentsList());
		return "studentRegistration";
	}

	@RequestMapping(path = "/student", method = RequestMethod.POST)
	public String addStudent(Student s) {
		service.addStudent(s);
		return "redirect:/student";
	}

	@RequestMapping(path = "/student/delete/{id}", method = RequestMethod.POST)
	public String deleteStudent(@PathVariable("id") Integer id) {
		service.deleteStudent(id);
		return "redirect:/student";
	}

	@RequestMapping(path = "/student/edit/{id}", method = RequestMethod.POST)
	public String updateStudent(@PathVariable("id") Integer id, Student s) {
		service.updateStudent(id, s);
		return "redirect:/student";
	}
	
//	@RequestMapping(path = "/student/payment", method = RequestMethod.GET)
//	public String payment() {
//		return "redirect:/payment";
//	}
}
