package com.studentDemo.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentDemo.student.beans.Payment;

public interface PaymentDao extends JpaRepository<Payment, Integer>{

}
