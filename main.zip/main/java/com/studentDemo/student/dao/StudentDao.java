package com.studentDemo.student.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentDemo.student.beans.Student;

public interface StudentDao extends JpaRepository<Student, Integer>{

}
