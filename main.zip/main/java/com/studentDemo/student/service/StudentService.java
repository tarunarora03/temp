package com.studentDemo.student.service;

import java.util.List;


import com.studentDemo.student.beans.Student;

public interface StudentService {

	public List<Student> getStudentsList();

	public void addStudent(Student s);

	void deleteStudent(int id);

	void updateStudent(int id, Student s);
}
