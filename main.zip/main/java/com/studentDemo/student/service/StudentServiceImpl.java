package com.studentDemo.student.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentDemo.student.beans.Student;
import com.studentDemo.student.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentRepo;


	ArrayList<Student> studentsList = new ArrayList<Student>() {
		private static final long serialVersionUID = 1L;
		{
			add(new Student(1, "tarun1", "asdg1@gmail.com", 1.2f, new Date()));
			add(new Student(2, "tarun2", "asdg2@gmail.com", 1.2f, new Date()));
			add(new Student(3, "tarun3", "asdg3@gmail.com", 1.2f, new Date()));
		}
	};

	@Override
	public List<Student> getStudentsList() {
		return studentRepo.findAll();
	}

	@Override
	public void addStudent(Student s) {
		s.setInsertedDate(new Date());
		studentRepo.save(s);
	}

	@Override
	public void deleteStudent(int id) {
		studentRepo.deleteById(id);
	}

	@Override
	public void updateStudent(int id, Student s) {
		Optional<Student> record = studentRepo.findById(id);
		if (record.isPresent()) {
			record.get().setEmail(s.getEmail());
			record.get().setName(s.getName());
			record.get().setGpa(s.getGpa());
			record.get().setInsertedDate(new Date());
			studentRepo.save(record.get());
		}
	}

}
