package com.studentDemo.student.service;

import java.util.List;

import com.studentDemo.student.beans.Payment;

public interface PaymentService {

	public boolean checkPaymentStatus(int id);

	public void makePayment(Payment p);

	public List<Payment> getAllPayments();

	public Payment getStudents();
}
