package com.studentDemo.student.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentDemo.student.beans.Payment;
import com.studentDemo.student.beans.Student;
import com.studentDemo.student.dao.PaymentDao;
import com.studentDemo.student.dao.StudentDao;

@Service
public class PaymentServiceImpl implements PaymentService{
	
	@Autowired
	PaymentDao paymentRepo;
	@Autowired
	StudentDao studentRepo;


	@Override
	public List<Payment> getAllPayments() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Payment getStudents() {
		List<Student> stList = studentRepo.findAll();
		Payment pm = new Payment();
		stList.forEach(st -> pm.getStudentMap().put(st.getId(),st.getName()));
		
		return pm;
	}


	@Override
	public boolean checkPaymentStatus(int id) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void makePayment(Payment p) {
		p.setInsertedDate(new Date());
		paymentRepo.save(p);
		
	}
}
